﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PROJECT_QUIZ.Models.Models
{
    public class Leaderboard
    {
        public string Score { get; set; }
        public string Username { get; set; }
    }
}
